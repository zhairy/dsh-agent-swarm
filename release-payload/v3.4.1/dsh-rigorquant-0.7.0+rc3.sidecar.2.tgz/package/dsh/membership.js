// 弱引用按 Agent 和操作去重；仅记录固定操作/分类，不输出错误 message、历史或输入。
const reported = new WeakMap()
function report(agent, operation, error, warn = message => console.warn(message)) {
  const expected = error?.code === 'UNAUTHORIZED'
  const category = expected ? 'identity-not-published-or-unavailable' : 'unexpected-service-failure'
  const key = `${operation}:${category}`
  const seen = reported.get(agent) ?? new Set()
  if (seen.has(key)) return
  seen.add(key)
  reported.set(agent, seen)
  // UNAUTHORIZED 也可能表示已失效身份；仅标记不可用，不将其推断为允许冷恢复。
  warn(`rq-team: operation=${operation} category=${category}; trusted identity denied`)
}

/** 同步公共身份；enabled=false 只表示已证明的身份，绝不授予 Team 能力。 */
export function getMembership(agent, teams, subagents, warn) {
  if (!teams) return undefined
  let operation = 'membership'
  try {
    if (typeof teams.tryMembership === 'function') return teams.tryMembership(agent)
    operation = 'isEnabled'
    if (typeof teams.isEnabled !== 'function') throw new TypeError('missing public Team capability')
    const enabled = teams.isEnabled(agent)
    if (typeof enabled !== 'boolean') throw new TypeError('invalid public Team mode')
    operation = 'rootOf'
    const root = subagents.rootOf(agent)
    operation = 'namesOf'
    const names = subagents.namesOf(agent)
    if (root === agent && names.self === 'lead' && names.parent === undefined) return { id: agent.id, name: 'lead', role: 'lead', depth: 0, enabled }
    if (root !== agent && typeof names.self === 'string' && typeof names.parent === 'string') return { id: agent.id, name: names.self, role: 'teammate', depth: names.self.split('/').length, enabled }
    throw new TypeError('inconsistent public member identity')
  } catch (error) {
    report(agent, operation, error, warn)
    return undefined
  }
}

/** 当前加载的启用成员，绝不宣称是完整持久名单。 */
export function loadedMembers(lead, teams, agents, subagents, warn) {
  try {
    if (typeof teams?.listMembers === 'function') return teams.listMembers(lead)
    const result = []
    for (const agent of agents?.list() ?? []) {
      const member = getMembership(agent, teams, subagents, warn)
      if (!member || member.enabled === false) continue
      try {
        if (subagents.rootOf(agent) === lead) result.push({ ...member, status: agent.status })
      } catch (error) {
        report(agent, 'loadedMembers.rootOf', error, warn)
      }
    }
    return result
  } catch (error) {
    report(lead, 'loadedMembers.list', error, warn)
    return []
  }
}
