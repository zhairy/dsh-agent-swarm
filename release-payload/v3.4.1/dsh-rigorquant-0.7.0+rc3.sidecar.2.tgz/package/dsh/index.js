import { getMembership } from './membership.js'
// RigorQuant model router — host half.
//
// The router row's own profile config maps every RigorQuant role to a primary
// model and a per-role fallback model, each with its own reasoning effort
// (Decision 25: the harness has no plugin-registered settings namespace for
// the routes to live in). Each `<role>Primary`/`<role>Fallback` field is
// `.volatile()`, so a saved route reaches the next request without a
// remount. No native per-role model row remains under Agent Teams — a
// teammate is created by `spawn_teammate`, which carries no model choice at
// all — so this router carries the shipped tier matrix itself
// (`DEFAULT_PRIMARY`/`DEFAULT_FALLBACK`) and a route the user saved always
// wins over it. The `agent/request` waterfall remains the small policy
// overlay that makes live config and fallback possible.
//
// Account fallback: the harness splits DeepSeek into `deepseek-official`
// (API key) and `deepseek-account` (account sign-in). When the official
// route is not routable but the account route is, the SHIPPED matrix moves
// to the same model ids on `deepseek-account`; a saved route is never moved.
// "Routable" is the model catalog's rule (the provider lists at least one
// model), plus, for the official route, a configured API key: its catalog
// is advertised with or without a key, so the catalog alone would never
// send an account-only user anywhere else.
//
// Role identity (docs/architecture.md Decision 24, amending Decision 23):
// the teammate's NAME is the role. Every agent's Team membership is read
// duck-typed off the optional `agentTeams` service
// (`ctx.get('agentTeams').tryMembership(agent)`, the same call
// `dsh/team.js` resolves composition from) — the Lead is the orchestrator
// (`root`); every other member's role is parsed from its name
// (`<role>-<n>`). An agent with no membership, or whose live composition is
// not this preset, is never touched: it keeps the chatbox/parent model
// exactly as before. The classic persona-tag regex, the persona-assembly
// probe that read a one-shot child's live prompt section, and the
// deprecated synchronous session-event reads that found a continuable
// child's descriptor are gone — nothing here reads history or prompt text
// to find a role anymore.
//
// Degrade lane: when the primary route of a routed role fails terminally
// (no adapter, a model its provider does not declare or cannot resolve, or
// an HTTP 4xx the route cannot recover from), the listener marks that
// session+role degraded and forces one retry, which re-enters agent/request
// and routes to the role's fallback. A successful assistant step on the
// fallback — or the TTL — restores the primary. A fallback that also fails is
// never retried again by this plugin (no retry loop). Every degrade and every
// route-fatal give-up (the fallback failed too, or the role has no fallback)
// is one warning naming the role, the route, and the config key it came
// from: the teammate's own failure surfaces only as an unaccepted initial
// prompt.
//
// Effort fallback: a stored choice may carry a reasoning effort the exact
// route's model does not support — a model with no reasoning surface at all,
// or one that does not list the saved level. The LLM service rejects such a
// request before any provider I/O (UNSUPPORTED_REASONING_EFFORT) and the
// turn dies with it, so the router consults the model's real effort metadata
// while routing and drops a refused effort: the model's default level
// governs and the stored choice's model override stays intact. A route whose
// metadata cannot be resolved fails open — the request path reports it
// exactly as before.

import z from '@deepseek-ai/schemastery'

const name = 'rq-model-router'

/** Every routable role, in card order. */
export const ROLES = ['root', 'explorer', 'offgrid', 'doublechecker', 'adversary', 'lit-line', 'lit-adversary', 'doc-adversary']
/** Every teammate role, i.e. `ROLES` minus the Lead-only `root` — the same
 *  set `dsh/team.js`'s `TEAMMATE_ROLES` names. Declared here rather than
 *  imported: `dsh/client.js`'s browser bundle carries the same set as a
 *  third independent copy and structurally cannot import either Node
 *  module, so every surface already owns its own copy pinned equal by
 *  tests/test_repo_consistency.py — importing here would leave two of
 *  three surfaces sharing source and one not, for no behavioural gain. */
const TEAMMATE_ROLES = ROLES.filter((role) => role !== 'root')
/** Teammate name convention: `<role>-<suffix>`, e.g. `doublechecker-1` — the
 *  same contract `dsh/team.js`'s `NAME_PATTERN` parses membership by. */
const NAME_PATTERN = new RegExp(`^(${TEAMMATE_ROLES.join('|')})-.+$`)

/** Parse a teammate's role from its Team membership name, or `null` when it
 *  doesn't parse (an unparseable name should already have been refused at
 *  `spawn_teammate` by `dsh/team.js`'s Lead guard; this is defense in depth,
 *  not the enforcement point). */
function roleFromName(teammateName) {
  const match = typeof teammateName === 'string' ? NAME_PATTERN.exec(teammateName) : null
  return match !== null ? match[1] : null
}

const choiceSchema = z.object({
  provider: z.string().required(),
  model: z.string().required(),
  reasoningEffort: z.string(),
})

/** Every per-role route field, `<role>Primary` and `<role>Fallback`. The ONE
 *  list of route fields: `Config` is built from it and the probes read it back
 *  through the module, so a route cannot exist in one place and not the
 *  other. */
const ROUTE_KEYS = ROLES.flatMap((role) => [`${role}Primary`, `${role}Fallback`])

/** The role and the slot a route field name carries. The suffix is fixed, so
 *  the split cannot be ambiguous (`lit-adversaryPrimary` gets `lit-adversary`). */
function routeOf(key) {
  const [, role, slot] = /^(.*)(Primary|Fallback)$/.exec(key)
  return { role, slot }
}

// Decision 16's shipped routes. `deepseek-flash` is DeepSeek-V41-Flash
// (efforts off|low|high|max), the flash tier the default catalog lists.
const OFFICIAL = 'deepseek-official'
const ACCOUNT = 'deepseek-account'
const DEFAULT_PRIMARY = Object.freeze({ provider: 'deepseek-official', model: 'deepseek-v4-pro', reasoningEffort: 'high' })
const DEFAULT_FALLBACK = Object.freeze({ provider: 'deepseek-official', model: 'deepseek-flash', reasoningEffort: 'low' })

/** The shipped tier matrix: proof-critical roles on pro with a flash
 *  fallback; every other role absent (inherit the session model). */
const SHIPPED = Object.freeze({
  doublecheckerPrimary: DEFAULT_PRIMARY,
  doublecheckerFallback: DEFAULT_FALLBACK,
  adversaryPrimary: DEFAULT_PRIMARY,
  adversaryFallback: DEFAULT_FALLBACK,
})

/** The human name of every role, for text a person reads.
 *
 *  The card's locale copy is a second, richer rendering of these names
 *  ("Explorer (method track)"); the two surfaces must not name one model route
 *  differently, so `test_repo_consistency.py` pins each label here as the
 *  leading name of the card's `role.<role>` string. "Root orchestrator" keeps
 *  the card's wording deliberately: CONTEXT.md avoids "root" as a NAME for the
 *  orchestrator in prose, but this is the label of the harness's `root` role
 *  on a settings page, and it must read the same in both places. */
const ROLE_LABELS = Object.freeze({
  root: 'Root orchestrator',
  explorer: 'Explorer',
  offgrid: 'OffGridThinker',
  doublechecker: 'DoubleChecker',
  adversary: 'Adversary',
  'lit-line': 'Literature line',
  'lit-adversary': 'Literature adversary',
  'doc-adversary': 'Document adversary',
})

/**
 * One route field's description.
 *
 * The harness's own settings page is generated from this schema
 * (`SettingsForms` projects a row's Config, and `volatileForm` keeps exactly
 * the `meta.volatile` fields), so a description here is the only text a person
 * editing the row natively ever sees: it has to say WHICH role and WHICH slot,
 * not merely what a choice object is. The card remains the rich editor.
 * @param role - one of {@link ROLES}.
 * @param slot - `Primary` or `Fallback`.
 */
function routeDescription(role, slot) {
  const inherits = SHIPPED[`${role}${slot}`] === undefined
  return `${ROLE_LABELS[role]} — ${slot.toLowerCase()} route: provider and model, with an optional `
    + `reasoning-effort level. Unset ${inherits ? 'inherits the session route' : 'takes the shipped tier'}.`
}

/** Flat on purpose: every field is a whole choice object the card writes
 *  whole, and a volatile field must sit at a fixed object path. The shipped
 *  matrix is NOT a schema default: a default would make a saved route and an
 *  unsaved one indistinguishable, and only an unsaved one may move to the
 *  account route. `.default(void 0)` keeps an absent field absent:
 *  schemastery otherwise materializes a missing object field as `{}` and
 *  rejects its required inners. */
const Config = z.object({
  presetId: z.string().default('rigorquant'),
  degradeTtlMs: z.number().default(600000),
  ...Object.fromEntries(ROUTE_KEYS.map((key) => {
    const { role, slot } = routeOf(key)
    return [key, choiceSchema.description(routeDescription(role, slot)).default(void 0).volatile()]
  })),
})

function isRecord(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function isChoice(value) {
  return isRecord(value)
    && typeof value.provider === 'string' && value.provider !== ''
    && typeof value.model === 'string' && value.model !== ''
}

/** Codes meaning the exact provider/model pair cannot be resolved at all,
 *  each thrown before any provider I/O with a code and no status: no adapter
 *  owns the provider (`NO_ADAPTER`, from the LLM service or the adapter), the
 *  provider does not declare the model (`UNKNOWN_MODEL`), or its declaration
 *  is broken (`INVALID_CONFIG` — llm-pi-ai's configured-model lookup throws it
 *  for that model's config error or its provider's failed catalog, and
 *  nowhere else). */
const UNRESOLVABLE_ROUTE_CODES = new Set(['NO_ADAPTER', 'UNKNOWN_MODEL', 'INVALID_CONFIG'])

/** A failure the route itself cannot recover from: an unresolvable route or
 *  bad primary.
 *
 * Providers should surface numeric HTTP status, but the official usage-limit
 * response currently exposes its provider code (`1308`) and message while some
 * adapter paths omit `status`. Treat that specific quota exhaustion as terminal
 * too: retrying the same primary cannot help, whereas the role fallback can.
 */
function routeFatal(failure) {
  if (failure === undefined || failure === null) return false
  if (UNRESOLVABLE_ROUTE_CODES.has(failure.code)) return true
  const status = typeof failure.status === 'number'
    ? failure.status
    : typeof failure.status === 'string' ? Number(failure.status) : NaN
  if (Number.isFinite(status) && status >= 400 && status < 500) return true
  return failure.code === '1308' && /usage limit reached/i.test(String(failure.message ?? ''))
}

/** The failure's own identity for a log line: its code, else its status. */
function failureLabel(failure) {
  return String(failure?.code ?? failure?.status ?? 'unknown')
}

/** Apply a live override/fallback while clearing an inherited effort. */
function applyChoice(resolved, choice) {
  const { reasoningEffort: _inheritedEffort, ...withoutInheritedEffort } = resolved
  return {
    ...withoutInheritedEffort,
    provider: choice.provider,
    model: choice.model,
    ...typeof choice.reasoningEffort === 'string' && choice.reasoningEffort !== ''
      ? { reasoningEffort: choice.reasoningEffort }
      : {},
  }
}

function apply(ctx, config) {
  /** sessionId → { role, until, provider, model, choice, gaveUp } while
   *  degraded: `choice` is the fallback degraded to, `gaveUp` whether its own
   *  failure has already warned. */
  const degraded = new Map()
  /** The exact resolved request route, for error-to-primary attribution. */
  const requested = new Map()
  /** provider::model → Set of the effort ids the model's own metadata lists
   *  (empty when it takes no explicit effort at all). Failed lookups are never
   *  cached: a transient registry miss retries on the next request. */
  const effortSurfaces = new Map()
  /** Routes whose effort was dropped, so the fallback logs once per route. */
  const effortFallbacks = new Set()
  /** agentId → the provider/model its no-fallback give-up already warned
   *  about, so a teammate whose every turn dies on it warns once. */
  const noFallbackWarned = new Map()

  /**
   * The reasoning-effort surface of one exact route, from the same `llm`
   * service the model catalog serves the card from. `undefined` means the
   * route could not be resolved (unregistered adapter, unknown model) and the
   * caller must fail open: the request path reports such a route itself.
   */
  async function effortSurface(provider, model) {
    const key = `${provider}::${model}`
    const cached = effortSurfaces.get(key)
    if (cached !== undefined) return cached
    try {
      const info = await ctx.get('llm').resolveModelInfo(provider, model)
      const surface = new Set(info.reasoning?.efforts.map((effort) => effort.id) ?? [])
      effortSurfaces.set(key, surface)
      return surface
    } catch {
      return undefined
    }
  }
  // Adapter (re)registration — a profile edit, an HMR swap — can change what a
  // model supports; drop the cache so the next request re-resolves it.
  ctx.on('llm/adapters-updated', () => {
    effortSurfaces.clear()
  })

  /**
   * Fall back to the model's default effort level when the carried effort is
   * one the exact route refuses. The LLM service rejects such a request
   * before any provider I/O and the turn dies with no recovery — the failure
   * never reaches agent/request-error — so the effort is dropped here, where
   * routing happens. An empty surface (no reasoning metadata) refuses every
   * explicit effort; a listed effort passes through untouched.
   */
  async function withSupportedEffort(route) {
    const effort = route?.reasoningEffort
    if (typeof effort !== 'string' || effort === '') return route
    const surface = await effortSurface(route.provider, route.model)
    if (surface === undefined || surface.has(effort)) return route
    const key = `${route.provider}::${route.model}`
    if (!effortFallbacks.has(key)) {
      effortFallbacks.add(key)
      ctx.logger.info(
        `rq-model-router: ${route.provider}/${route.model} does not support reasoning`
        + ` effort "${effort}"; falling back to the model default level`,
      )
    }
    const { reasoningEffort: _refused, ...withoutEffort } = route
    return withoutEffort
  }

  /** Whether one provider lists at least one model: the model catalog's
   *  own rule for a routable provider. A failed listing is not routable. */
  async function listsModels(provider) {
    const llm = ctx.get('llm')
    if (llm === undefined) return false
    try {
      if (!llm.listProviders().some((entry) => entry.id === provider)) return false
      return (await llm.listModels(provider)).length > 0
    } catch {
      return false
    }
  }

  /** Whether the official route has an API key, read the way the harness's
   *  own default-model initialisation reads it: the route's `apiKeyEnv`
   *  reference, described by the credentials service. When that cannot be
   *  read at all, the key is assumed present, so the shipped matrix stays
   *  where it always was. */
  async function officialKeyConfigured() {
    const llm = ctx.get('llm')
    const settings = ctx.get('settings')
    const credentials = ctx.get('credentials')
    if (llm === undefined || settings === undefined || credentials === undefined) return true
    try {
      const entry = llm.listConfigurableProviders().find((provider) => provider.provider === OFFICIAL)
      if (entry === undefined) return true
      let value = settings.describe({ redactSecrets: true }).find((view) => view.ns === entry.settingsNs)?.value
      for (const key of entry.settingsPath) value = isRecord(value) ? value[key] : undefined
      const ref = isRecord(value) && typeof value.apiKeyEnv === 'string' && value.apiKeyEnv !== ''
        ? value.apiKeyEnv
        : 'DEEPSEEK_API_KEY'
      return (await credentials.describe(ref)).configured === true
    } catch {
      return true
    }
  }

  /** The provider the shipped matrix routes to right now: the account route
   *  when the official one is not routable and the account one is, else
   *  the official route (whose own failure then takes the degrade lane). */
  async function shippedProvider() {
    if (await listsModels(OFFICIAL) && await officialKeyConfigured()) return OFFICIAL
    return await listsModels(ACCOUNT) ? ACCOUNT : OFFICIAL
  }

  /** One slot's route: the saved route when the user saved one, else the
   *  shipped matrix's (moved to the account route when only that one is
   *  routable), else `null` — inherit. */
  async function routeFor(role, slot) {
    const key = `${role}${slot}`
    const saved = config[key]?.get()
    if (isChoice(saved)) return saved
    const shipped = SHIPPED[key]
    if (shipped === undefined) return null
    const provider = shipped.provider === OFFICIAL ? await shippedProvider() : shipped.provider
    return provider === shipped.provider ? shipped : { ...shipped, provider }
  }
  const primaryFor = (role) => routeFor(role, 'Primary')
  const fallbackFor = (role) => routeFor(role, 'Fallback')
  /** One slot's route for a warning: the role, the route, and where it came
   *  from — the config key the operator edits, marked as the shipped
   *  default when no route is saved under it. */
  const describeRoute = (role, slot, choice) => {
    const key = `${role}${slot}`
    const shipped = !isChoice(config[key]?.get())
    return `${role} ${slot.toLowerCase()} ${choice.provider}/${choice.model} `
      + `(config key ${key}${shipped ? ', shipped default' : ''})`
  }

  ctx.on('session/event', (session, event) => {
    if (event.type === 'assistant/message') {
      const d = degraded.get(session.id)
      const source = event.data?.message?.source
      if (d !== undefined && source !== undefined
        && source.model === d.model
        && (d.provider === undefined || source.provider === d.provider)) {
        degraded.delete(session.id)
      }
    }
  })
  ctx.on('session/disposed', (session) => {
    degraded.delete(session.id)
    requested.delete(session.id)
    noFallbackWarned.delete(session.id)
  })
  ctx.on('agent/disposed', ({ agent }) => {
    degraded.delete(agent.id)
    requested.delete(agent.id)
    noFallbackWarned.delete(agent.id)
  })

  /** The teammate's role, resolved purely from its Team membership — never
   *  from history or prompt text. `agentTeams` is optional and reached
   *  duck-typed, the same contract `dsh/team.js` mounts against; absent
   *  (Agent Teams not enabled) or no membership (not a team member, e.g. a
   *  classic fork/workflow child) both mean "not routable" here. The Lead is
   *  the orchestrator (`root`); every other member's role comes from its
   *  name. Only agents whose LIVE composition is this preset are touched —
   *  a Lead or teammate of some other team is left alone. */
  function resolveRole(agent) {
    if (ctx.get('agentPresets')?.composedPreset(agent.ctx) !== config.presetId) return null
    const teams = ctx.get('agentTeams')
    if (teams === undefined) return null
    const membership = getMembership(agent, teams, ctx.get('subagents'), message => ctx.logger.warn(message))
    if (membership === undefined || membership.enabled === false) return null
    const inRigorQuant = ctx.get('agentPresets')?.composedPreset(agent.ctx) === config.presetId
    if (!inRigorQuant) return null
    return membership.role === 'lead' ? 'root' : roleFromName(membership.name)
  }

  const stepModelBridge = Symbol.for('dsh-agent-swarm/step-model-bridge-v1')
  const routeRequest = async (payload, next) => {
    const resolved = await next()
    const role = resolveRole(payload.agent)
    if (role === null || role === undefined) return resolved
    const agentId = payload.agent.id
    const remember = (route) => {
      requested.set(agentId, { role, provider: route.provider, model: route.model })
      return route
    }
    const d = degraded.get(agentId)
    const active = d !== undefined && d.role === role && d.until > Date.now()
    if (active) {
      const fallback = await fallbackFor(role)
      // A live config edit can remove a fallback while a retry is pending.
      // Do not keep forcing an absent route; let the inherited route run.
      if (fallback === null) {
        degraded.delete(agentId)
        return remember(await withSupportedEffort(resolved))
      }
      d.provider = fallback.provider
      d.model = fallback.model
      d.choice = fallback
      return remember(await withSupportedEffort(applyChoice(resolved, fallback)))
    }

    // The primary is the saved route, else the shipped tier matrix; a role
    // with neither (every role but DoubleChecker/adversary, absent a saved
    // route) inherits the resolved route untouched.
    const primary = await primaryFor(role)
    return remember(await withSupportedEffort(
      primary === null ? resolved : applyChoice(resolved, primary),
    ))
  }

  ctx.on('agent/swarm-model-select', async (payload, next) => {
    if (payload.agent?.[stepModelBridge] !== true) return next()
    return routeRequest(payload, next)
  })
  ctx.on('agent/request', async (payload, next) => {
    if (payload.agent?.[stepModelBridge] === true) return next()
    if (typeof payload.agent?.model?.current === 'function' && typeof payload.agent?.model?.select === 'function'
      && resolveRole(payload.agent) != null) throw new Error('RigorQuant model routing requires the DSH 0.2.2 step-model bridge; no request was sent')
    return routeRequest(payload, next)
  })

  ctx.on('agent/request-error', async (payload, next) => {
    const action = await next()
    const role = resolveRole(payload.agent)
    if (role === null || role === undefined) return action
    if (!routeFatal(payload.failure)) return action
    // Only act on failures on OUR route: compare against the exact route
    // resolved for this request, not merely the static defaults. This keeps
    // an unrelated picker route out of the fallback lane while correctly
    // covering the shipped matrix and a user override alike.
    const agentId = payload.agent.id
    const route = requested.get(agentId)
    if (route === undefined || route.role !== role || route.provider !== payload.provider) return action
    const cause = failureLabel(payload.failure)
    const d = degraded.get(agentId)
    if (d !== undefined && d.role === role && d.until > Date.now()) {
      // The degraded retry itself failed: never retried again (no loop).
      if (!d.gaveUp && route.model === d.model) {
        d.gaveUp = true
        ctx.logger.warn(
          `rq-model-router: ${describeRoute(role, 'Fallback', d.choice)} also failed (${cause}); `
          + 'not retried, the turn fails',
        )
      }
      return action
    }
    const primary = await primaryFor(role)
    if (primary === null || route.model !== primary.model) return action
    const fallback = await fallbackFor(role)
    if (fallback === null) {
      const routeKey = `${primary.provider}/${primary.model}`
      if (noFallbackWarned.get(agentId) !== routeKey) {
        noFallbackWarned.set(agentId, routeKey)
        ctx.logger.warn(
          `rq-model-router: ${describeRoute(role, 'Primary', primary)} failed (${cause}) `
          + `and ${role}Fallback is unset: no fallback to degrade to, the turn fails`,
        )
      }
      return action
    }
    degraded.set(agentId, {
      role,
      until: Date.now() + config.degradeTtlMs,
      provider: fallback.provider,
      model: fallback.model,
      choice: fallback,
      gaveUp: false,
    })
    ctx.logger.warn(
      `rq-model-router: ${describeRoute(role, 'Primary', primary)} failed (${cause}); `
      + `degraded to ${fallback.provider}/${fallback.model} `
      + `for ${Math.round(config.degradeTtlMs / 60000)} min`,
    )
    return { kind: 'retry' }
  })
}

export { Config, name, apply, DEFAULT_PRIMARY, DEFAULT_FALLBACK }
