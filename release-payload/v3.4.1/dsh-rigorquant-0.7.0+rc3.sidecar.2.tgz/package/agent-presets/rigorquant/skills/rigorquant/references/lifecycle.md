# Lifecycle, registry, and termination

## study.json schema

Created at intake (SKILL.md Step 1); internal references recorded anywhere in
a study (registry.json, journal.md, audits) are study-root-relative.

```json
{
  "slug": "YYYYMMDD_<kebab-topic>[_v<N>] — intake date + topic; see SKILL.md Step 1",
  "title": "one-line title",
  "mode": "repo-root | multi-study",
  "repo_root": "<absolute path resolved at intake>",
  "env_lane": "env",
  "task_id": "<problem id>",
  "created": "YYYY-MM-DD",
  "intake_pins": { "schema_sha256": "...", "validator_sha256": "..." },  # optional; hard-lessons L7
  "statement": "the problem statement",
  "broad_criterion": "the ORIGINAL broad claim a PASS must deliver, verbatim — never re-scoped to the simplified cases",
  "success_criterion": "summary of the broad criterion plus the stage evidence required",
  "subproblems": [
    { "id": "SPn", "name": "...", "status": "known|novel|impossible",
      "stage": "reference-case|generalization|domain-scale",
      "success_criterion": "...", "evidence_level": "..." }
  ],
  "validity_stages": {
    "stage3_general_claim": { "claim": "...", "claim_sha256": "...", "evidence_level": "...", "outputs": ["..."] },
    "stage5_domain_scale": { "instance": "...", "outputs": ["..."] }
  },
  "deliverables": {
    "paper": "required",
    "slides": "required | not-required:<reason recorded at intake>",
    "web": "optional | required",
    "consultation_pending": false,
    "consultation_record": { "date": "...", "agent": "...", "artifacts_read": ["..."] },
    "last_accepted": { "paper": {...}, "slides": {...}, "web": {...} },
    "audience": {
      "paper": { "role": "...", "level": "...", "sentence": "...",
                 "assume_known": ["..."], "must_define": ["B(", "poly", "O*"],
                 "avoid": ["..."], "depth": "...", "format": "..." },
      "slides": { "...": "..." },
      "web": { "...": "..." }
    }
  },
  "simplified_cases": ["..."],
  "seeds": { "task_seed": 0, "convention": "per-run seed = task_seed + run_index" },
  "tolerances": {
    "deterministic": { "abs": "...", "rel": "..." },
    "stochastic": { "se_units": 3, "confidence": 0.95, "lln_grid": [1000, 10000, 100000] }
  },
  "budget": { "max_orchestrator_rounds": 3, "max_cost_usd": null, "max_wall_minutes": null },
  "literature": {
    "phase": "not-run | running | concluded | skipped",
    "skip_reason": "the verbatim user assertion — required when phase is skipped",
    "consulted_at": "YYYY-MM-DD",
    "map_file": "literature/known-results.json",
    "negative_exports_file": "literature/negative-exports.json",
    "completeness_file": "literature/completeness.json",
    "refs_seed_file": "literature/refs-seed.bib",
    "budget": { "max_lines": 4, "max_depth": 3, "max_papers_per_line": 20, "max_rounds": 4 }
  },
  "status": "per-sub-problem status + current round; a PASS is claimed ONLY when this string begins with the token PASS"
}
```

The machine-readable version of this schema is
`<skill-dir>/schemas/study.schema.json`, and it is the file `rq_check.py`
actually loads — the JSON above is its human-facing mirror. If the two ever
disagree, the schema file wins and `tests/` fails.

Notes on the schema:

- **PASS claim detection.** `status` is free text with one rule: it claims a
  PASS only if it *begins* with `PASS`. `"round 2: SP3 active, no PASS yet"` is
  not a claim and does not trip the PASS gates. A status that begins with PASS
  but is also marked reopened (e.g. "PASS reopened") is likewise not a claim:
  the study re-entered active work, so the PASS gates do not fire.
- **Status is written from verdicts (hard-lessons L4).** A status string that
  asserts a certification outcome — certified, verdict, ruling, restored,
  adjudicated, needs-edits — must reference the verdict file or frozen snapshot
  hash it rests on; `rq_check.py` refuses a verdictless status claim. No status
  string may assert a certification outcome that no independent verdict has
  established: status prose is what a resumed session reads first, and if it
  lies, every subsequent decision inherits the lie.
- **The record is the source of truth (hard-lessons L6).** Load-bearing
  text — claims, audience sentences, evidence levels — lives once, in
  `study.json`, and the documents quote it. A change to such text reopens the
  certification it participates in; record the change with its reason and its
  new digest (`stage3_general_claim.claim_sha256`).
- **Schema and validator pins (hard-lessons L7).** At intake, record
  `intake_pins` (`schema_sha256`, `validator_sha256`) — digests of the
  `study.schema.json` and `rq_check.py` in effect. A mid-run reissue that
  rejects the study is a re-intake event, never an on-the-fly repair;
  `rq_check.py` flags a recorded pin mismatch.
- `mode` is the clean enum `"repo-root" | "multi-study"` (never a literal path
  or a `<...>` placeholder).
- `env_lane` is `"env"`: the study's own pinned lane at `<study-root>/env/`
  (`pyproject.toml` + `uv.lock`, committed), copied from the template at
  `$DSH_HOME/share/rigorquant/env`. It is **not** persisted at intake — Step 2
  creates `env/` and adds it. An absolute path to the same directory is
  accepted; the template itself is not (`evidence.lane` refuses the PASS).
- `tolerances` splits deterministic and stochastic acceptance (see
  check-battery.md): deterministic methods use condition-aware absolute and
  relative tolerances; stochastic methods agree in standard-error /
  confidence-interval units, never a universal `1e-12`.
- **Deliverables rule:** `paper` is always `"required"`; `slides` is
  `"required"` unless the intake records a reason for `"not-required"`;
  `web` is `"optional"` unless the study will produce interactive/visual
  artifacts (widgets, movies, dashboards), in which case it is `"required"`.
  The artifacts are produced at PASS only, assembled from validated records
  (see references/deliverables.md); `rq_check.py` enforces the declaration at
  intake and existence + structure + no-overclaim at PASS.
- **Coverage rule:** the union of sub-problem stages must cover the original
  statement. Every general question requires at least one `generalization`
  sub-problem (the broad claim is its criterion) and at least one
  `domain-scale` sub-problem (certification on a genuinely non-special
  instance). A study whose simplified cases are box/ball/simplex/ellipsoid (or
  a portfolio study's diagonal covariance) must not PASS on evidence from those
  same special bodies alone; rq_check.py refuses an instance that names only
  such a body (box/ball/simplex/ellipsoid/diagonal) or restates a simplified
  case.
  `<skill-dir>/scripts/rq_check.py --study <study-root>` enforces this at intake
  and at PASS, and refuses a PASS unless `validity_stages` stage-3 and stage-5
  each record non-empty `outputs` that resolve to files that exist and stay inside the study root (absolute or
  ".."-escaping paths, and the validator's own report, are refused).

## registry.json schema (subproblems map)

```json
{
  "task": "<problem id>",
  "rounds": 0,
  "subproblems": {
    "SP1": {
      "status": "active | blocked | passed | dead | unknown",
      "blockedReason": "exact remaining gap (only when blocked)",
      "blockedRounds": 0,
      "evidence_level": "falsification-surviving | independently re-derived | certificate-checked | formally verified",
      "families": [
        {
          "familyId": "kebab-case idea name",
          "idea": "one sentence: the mathematical mechanism",
          "routes": [
            {
              "routeId": "kebab-case",
              "status": "active | blocked | dead | passed",
              "blockedReason": "exact remaining gap (only when blocked)",
              "mechanism": "what changed when reopened",
              "outputs": ["study-root-relative paths to concrete derivations/artifacts"]
            }
          ]
        }
      ]
    }
  }
}
```

Rules: key the map by sub-problem id (`SPn`) so each sub-problem keeps its own
`blockedReason` and `blockedRounds` counter — a synthesis that alternates
sub-problems must not overwrite another's state. Group families by mathematical
idea, never by wording; a route with a theorem-strength missing lemma is
`blocked`, not `active`; `dead` requires a counterexample reference; `passed`
requires an audit reference.

## Evidence levels

Tag every load-bearing claim with one of:

- **falsification-surviving** — the claim survived the adversary and the check
  battery.
- **independently re-derived** — two independent ground-truth derivations
  agree.
- **certificate-checked** — a machine-checked certificate (SAT/SMT/prover
  artifact, jacobian `verify`) establishes the claim.
- **formally verified** — a Lean proof with a recorded axiom audit establishes
  it.

Only certificate-checked or formally-verified claims conclusively settle
load-bearing claims; the first two are strong evidence, not settlement.

## Validity stages

PASS is defined against the check battery, which is a **reference-case sanity
gate** — passing it does not establish general validity. Establish validity in
stages:

1. Specification, assumptions, and applicability domain.
2. Independent reference-case oracle (the battery's A/B targets).
3. General proof, certificate, or precisely bounded validity claim.
4. Numerical stability, conditioning, residual, and complexity analysis.
5. Domain-scale stress testing.
6. Empirical or out-of-sample validation where applicable.

Call the battery a sanity gate unless stages 3–6 are also satisfied.

Stages 3 and 5 are **mandatory for a broad claim**, not optional polish:
stage 3 = the general validity claim with all hypotheses and an evidence
level; stage 5 = the full battery on a genuinely non-special instance. Record
them in `study.json` `validity_stages`. A PASS recorded without stage-3 and
stage-5 evidence is invalid, and the meta-validator
(`python3 <skill-dir>/scripts/rq_check.py --study <study-root>`) refuses it.

## Terminal states

- **research-complete** — an intermediate, explicit state reached when every
  subproblem route is `passed`, `validity_stages` stage-3 + stage-5 evidence
  are recorded, and `rq_check.py` accepts the study with deliverable gates
  suppressed. It is visible in `study.json.status`. At this point the
  **one-time audience consultation** (references/deliverables.md) must fire
  before any deliverable is crafted; until it is answered,
  `deliverables.consultation_pending` is `true` and a PASS is refused. The
  user may dial the study back to `active` from this (or any later) state;
  dial-back sets `consultation_pending: true`, retains the audience spec as
  `deliverables.last_accepted`, and does **not** mark verified artifacts
  stale — invalidation is claim-driven only (an artifact loses validity when
  new research changes a load-bearing claim it asserts, via the "superseded"
  mechanism), never merely because a dial-back happened.
- **PASS** — the staged validity case (above) passes for the sub-problem. A
  study-level PASS additionally requires the `validity_stages` stage-3 and
  stage-5 evidence recorded, the declared `deliverables` produced
  (`artifacts/paper/main.tex`; `artifacts/slides/main.tex` when required;
  `artifacts/web/index.html` when required — assembled from validated records
  per references/deliverables.md), the **audience consultation completed**
  (`consultation_pending` false; `deliverables.audience.<name>` present for
  every declared deliverable), AND the meta-validator to accept it (run
  `python3 <skill-dir>/scripts/rq_check.py --study <study-root>` before declaring). A
  battery-only PASS on special cases is not a study PASS.
  Auto-implementation is allowed only under a safety protocol: create a branch
  or worktree, declare a **frozen write scope** (only the target artifact
  files), run the target's tests, and keep a rollback path (the pre-change
  commit). Never write into an arbitrary target repository without user
  confirmation; unattended writes are allowed only into the study's own
  `artifacts/`. Then mark the sub-problem PASS and proceed.
- **BLOCKED** — the SAME exact gap persisted for 3 consecutive orchestrator
  rounds (tracked per sub-problem in `registry.json` `blockedRounds`). Stop the
  sub-problem: deliver the strongest rigorously proved derivation and the exact
  remaining gap (Jin's terminal report). Do not pad it with partial results or
  "why it is hard".
- **Claim-keyed blocking — narrow before patch (hard-lessons L1).** BLOCKED is
  keyed on the *claim*, not the gap. After two consecutive NEEDS-EDITS on the
  same claim or section, the next round MUST either (a) narrow the claim's
  declared scope to what is certified, or (b) declare BLOCKED with the exact
  gap. A re-patch that changes only the mechanism, not the scope, is a defect.
  Rationale: repeated independent failures on one claim are evidence of
  over-scoping, and narrowing is strictly cheaper than the next patch.
- **UNKNOWN** — the refutation track found no counterexample and the proof
  track found no proof (or the correct answer is impossibility /
  non-identifiability / divergence). Record it as `unknown`; do not relabel it
  PASS or BLOCKED.
- **BUDGET** — 3 orchestrator rounds reached without PASS or a stable block,
  or `spawn_teammate` refused by the team's lifetime teammate cap
  (`maxMembers`, which counts every teammate ever created, failed ones
  included). Checkpoint registry.json + journal.md, deliver a status report
  naming which budget tripped, halt; one human turn re-arms (after a cap trip
  it may raise the override). Budget
  fields (`max_cost_usd`, `max_wall_minutes`) may be set to impose limits;
  unset means unbounded.

## Round accounting

Each orchestrator round = one pass through the five moves, Promise → Fan out
→ Ground-truth → Attack → Certify (Step 3 of SKILL.md). Increment `rounds` at
Certify. The board's tasks coordinate the round; they are never evidence and
never counted — the round count lives in `study.json`.
BLOCKED counting is per sub-problem: consecutive rounds where the same
`blockedReason` appears for that `SPn`; any materially new mechanism resets its
`blockedRounds`.

## Literature lane accounting

The lane is entered at intake (Step 2b of SKILL.md) — mandatorily, unless the
user explicitly asserts known/novel there, which is recorded as
`phase: "skipped"` plus a verbatim `skip_reason` — and is **re-enterable per
round** on a recorded trigger — "is X still open after the adversary's
counterexample?" is a legitimate reason to re-open it mid-study. Each line is
one teammate for the whole study, `lit-line-<n>` with `n` the line number
(lines are numbered 1, 2, … in the order they are created, so the line number
is the role's counter), and the study's one literature adversary is
`lit-adversary-<n>`: a re-entry briefs the existing teammates by message (only
while idle or inactive, protocol.md L3) rather than creating new ones, and a
new line takes the next number. Its budget
(`literature.budget`: `max_lines` / `max_depth` / `max_papers_per_line` /
`max_rounds`) is the **default finish target, not a floor**: a line concludes
at the budget with the strongest completed dossier and its remaining
completeness-checklist items recorded as open. Exceeding the budget requires
an **explicit user escalation** recorded in `study.json` `literature.budget`
(raising the numbers, or setting `max_cost_usd`) — a silent overrun is a
defect. The shipped defaults are bounded (max_lines 4 / max_depth 3 /
max_papers_per_line 20 / max_rounds 4); the completeness checklist gates what
a concluded line must have swept within that budget.

**Consult-human is a hard stop.** When the orchestrator cannot decide between
(a) more rounds, (b) conclude, and (c) unclear, it checkpoints the map, the
frontiers, and the checklist, then halts; one human turn re-arms it, exactly as
the session boundary does. Under a thoroughness mandate this is the only honest
alternative to guessing silently.

Set `literature.phase` to what the record actually supports: `concluded` only
once known-results.json holds verified state, and never while the checklist is
incomplete — `rq_check.py` refuses the disagreement.

## Provenance and reports

Every report, script, and summary must be hashable and auditable:

- Store the generating script path and its SHA-256 in every report.
- Hash inputs, code, outputs, and an environment manifest (Python version,
  OS/architecture, BLAS/device backend, JAX precision flags, solver status,
  every random stream including Hypothesis).
- Make reports immutable after the round completes.
- Generate the journal summary mechanically from the audit records; reject a
  summary that does not match its referenced artifacts.

Run the meta-validator before declaring any PASS, writing its report into the
audit trail:

```sh
python3 <skill-dir>/scripts/rq_check.py --study <study-root> --out <study-root>/audits/rq-check.json
```

`<skill-dir>` is the directory containing SKILL.md (see SKILL.md "the check
battery"). It validates `study.json` / `registry.json` against the schemas in
`<skill-dir>/schemas/`, checks evidence completeness and falsifiability against
the **audit record** (never against `study.json` itself), rejects a missing
N-grid, verifies every declared SHA-256, and refuses a PASS without mandatory
evidence. With `--out` it writes a report carrying the result, every problem
found, the state-file hashes, and an environment manifest; ship that report
alongside the audit.

## Goal wiring

Create the goal tool objective **once, for the whole study** (`create_goal`);
`max_goal_rounds` = remaining budget. There is no per-sub-problem goal — the
goal service supports one current same-session goal, and creating another
before the first is `complete` raises. Represent sub-problems in `registry.json`
/ `study.json` state only. `update_goal complete` on PASS; `update_goal blocked`
(with the concrete gap as blocked_reason) on BLOCKED after the 3-round rule.
