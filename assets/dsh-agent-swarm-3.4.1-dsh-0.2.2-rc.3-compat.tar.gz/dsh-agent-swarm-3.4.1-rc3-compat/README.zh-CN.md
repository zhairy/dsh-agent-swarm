# v3.4.1 第三方插件与兼容包

本文说明 v3.4.1 兼容包的可复现重建入口。该入口只构建本地候选兼容归档，不发布 Release，不安装 profile，不启动或重启服务，也不修改活动 bundle。

## 输入身份

- 旧兼容模板固定为 `dsh-agent-swarm-3.4.0-dsh-0.2.2-rc.3-compat.tar.gz`，SHA-256 为 `d039aa44b88b489aac848e0f465dfd003396bc64f810a71b1375ecdc9db3d0ee`。
- Notebook 使用调用时提供的精确 tgz 与 SHA-256。版本号从 tgz 内 `package/package.json` 动态读取，不在构建器中硬编码 snapshot 编号。
- Notebook 和 Subscriptions 的 composite patch 分别以未修改的 NPM baseline 为 `before`、发布组件 bytes 为 `after` 逐文件生成。不会串联仓库中的历史 phase patch。
- RigorQuant、OpenCode Go、OpenCode Live 和 calculator 从旧兼容模板原样保留，构建后会按整组件文件映射再次核对。

旧模板必须先通过当前仓库的 `scripts/verify-release-compat.mjs`。该检查会反查 `main`、`types`、`exports` 和 `dsh.bundle.patch` 声明，不能只依赖组件清单里已有的 SHA。

## 构建命令

以下命令在源码根目录执行。将路径替换为下载并核验后的输入；Notebook 版本和 SHA-256 取自本发布 `third-party-manifest.json`，构建成功仍须完成运行时验收。

```bash
node scripts/build-release-compat.mjs \
  --version 3.4.1 \
  --base-archive /path/to/dsh-agent-swarm-3.4.0-dsh-0.2.2-rc.3-compat.tar.gz \
  --base-sha256 d039aa44b88b489aac848e0f465dfd003396bc64f810a71b1375ecdc9db3d0ee \
  --notebook-tarball /path/to/verified-notebook.tgz \
  --notebook-sha256 VERIFIED_NOTEBOOK_SHA256 \
  --notebook-original /path/to/npm-notebook-0.4.2/package \
  --subscriptions-original /path/to/npm-subscriptions-0.9.13/package \
  --sdk /path/to/dsh-0.2.2-rc.3/node_modules \
  --out /path/to/new-output-directory
```

输出文件：

```text
dsh-agent-swarm-3.4.1-dsh-0.2.2-rc.3-compat.tar.gz
third-party-manifest.json
```

归档根目录为 `dsh-agent-swarm-3.4.1-rc3-compat/`。Swarm 主包不在本入口中构建。

## 自动处理

构建器会完成以下步骤：

1. 校验输入归档实际 SHA-256，并安全解包。
2. 拒绝 symlink、hardlink、绝对路径、`..`、`node_modules`、日志和凭据文件。
3. 验证旧模板六组件、DSH `0.2.2-rc.3`、许可证、声明入口和静态相对 import。
4. 用 Notebook tgz 完整替换旧 Notebook 目录，避免只叠加 overlay 导致缺文件。
5. 从原 NPM baseline 到最终组件重建 Notebook 与 Subscriptions composite patch。
6. 在临时副本执行 patch 的 apply、check、restore 往返；baseline-only 文档不会被删除。
7. 替换包内 `tools/verify-compat.mjs`，重新生成组件 `files`、`supportFiles`、`compat-manifest.json` 和 `SHA256SUMS`。
8. 更新 Notebook 实际版本、`runtimeFilesUnchanged=false`、`plugin-inventory.json` 和 Notebook 许可证。
9. 保持 KNOWN-ISSUES 的 v3.4.0 内容为历史基线，不把原计划改写为已完成。
10. 用当前仓库校验器验证暂存树，再生成确定性 tar/gzip。
11. 对生成的 tgz 重新安全解包，用包内新版 `tools/verify-compat.mjs` 和 `sha256sum -c` 复核。
12. 全部验证通过后才以拒绝覆盖模式写入 `--out`。

tar 条目和 `SHA256SUMS` 均排序；tar 的 `mtime`、`uid`、`gid` 固定为 0；gzip MTIME 固定为 0。相同输入重复构建应得到相同归档字节。

## Composite patch

`patches/notebook.json` 与 `patches/subscriptions.json` 的每个条目都记录：

- `beforeSha256`：NPM baseline 文件摘要；新增文件为 `null`。
- `afterSha256`：最终发布组件文件摘要。

统一 diff 保留无 EOF 换行标记。baseline 中存在但最终组件未发布的旧文档不从原始目录删除；patch 只覆盖最终发布组件路径。应用后可运行：

```bash
node dsh-agent-swarm-3.4.1-rc3-compat/tools/apply-plugin-compat.mjs \
  --plugin /path/to/original-package \
  --plan dsh-agent-swarm-3.4.1-rc3-compat/patches/notebook.json \
  --check
```

恢复仍使用同一 plan 和 `--restore`。不要在已叠加其他版本补丁的目录上应用。

## 验证边界

本入口输出中的 `releaseReady` 固定为 `false`。它证明的是：

- 固定模板和精确输入可重建；
- 指定 tgz 的包内容、入口、许可证、声明 overlay 和相对 import 可闭合；
- composite patch 可往返；
- 生成归档的内部清单和 SHA256SUMS 自洽；
- 四个保留组件与模板逐字节一致。

它不证明 Notebook 独立审查、真实 Host 安装、插件业务路径、浏览器交互、服务启动或发布资产下载验收已经完成。若 Notebook snapshot 后续升级，只需提供新的 tgz 和 SHA-256；构建器会读取实际版本并重新生成清单与补丁。
