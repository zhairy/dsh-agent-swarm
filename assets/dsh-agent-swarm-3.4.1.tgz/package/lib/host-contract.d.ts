/**
 * 宿主契约：dsh-agent-swarm 对 DSH 宿主的全部假设集中在此文件
 * 升级 DSH 时优先核对本文件与集成测试（tests/integration）
 */
/** 宿主行提供给预设行的服务名 */
export declare const SWARM_SERVICE = "agentSwarm";
/**
 * 跨插件约定：百工模式管理的会话登记在 globalThis 的这个键上。
 * 其他会改写路由的插件（例如 dsh-llm-fallbacks 的全局回退）读到后应跳过这些会话，
 * 由百工自己的路由链负责回退。值的形状见 ManagedAgentsInfo。
 */
export declare const MANAGED_AGENTS_KEY: unique symbol;
/** globalThis[MANAGED_AGENTS_KEY] 的形状 */
export interface ManagedAgentsInfo {
    version: 1;
    /** 该会话是否由百工管理：天枢等百工预设的根会话，以及百工委派出的专家子会话 */
    isManaged: (agent: unknown) => boolean;
}
/** dsh-base 注册的进程内子智能体后端 */
export declare const SPAWN_PROVIDER = "spawn";
/** spawn 在请求 outputSchema 时注入给子智能体的结构化提交工具 */
export declare const STRUCTURED_OUTPUT_TOOL = "structured_output";
/** 可选 Notebook 适配器的可信内部生命周期接口；不是模型可调用的 RPC。 */
export declare const NOTEBOOK_RUNTIME_KEY: unique symbol;
export interface NotebookRuntimePort {
    version: 1;
    shutdownSession: (agentId: string) => Promise<unknown>;
}
export declare const getNotebookRuntimePort: () => NotebookRuntimePort | undefined;
export declare const NOTEBOOK_METADATA_TOOLS: readonly ['nb_get', 'nb_context', 'nb_list_vars', 'nb_inspect_object', 'nb_cell_history', 'nb_error_context', 'nb_kernel_list'];
export declare const NOTEBOOK_MEMORY_TOOLS: readonly ['nb_new', 'nb_add_cell', 'nb_delete_cell', 'nb_move_cell', 'nb_edit_cell', 'nb_apply_suggestion', 'nb_revert_cell', 'nb_clear_outputs'];
export declare const NOTEBOOK_READ_TOOLS: readonly ['nb_open', 'nb_list', 'nb_set_cwd'];
export declare const NOTEBOOK_COMPUTE_TOOLS: readonly ['nb_run_cell', 'nb_run_all', 'nb_edit_and_run_cell', 'nb_kernel_restart', 'nb_kernel_restart_and_run_all', 'nb_kernel_restart_and_clear', 'nb_kernel_interrupt', 'nb_kernel_select'];
/** 能力 → 宿主工具候选名（0.1.7-alpha.2 实测）；jev 为本插件在天枢预设内注册的 7 个 Jev 判断工具 */
export declare const CAPABILITY_TOOL_CANDIDATES: {
    readonly read: readonly ["read", "read_image", "nb_get", "nb_context", "nb_list_vars", "nb_inspect_object", "nb_cell_history", "nb_error_context", "nb_kernel_list", "nb_new", "nb_add_cell", "nb_delete_cell", "nb_move_cell", "nb_edit_cell", "nb_apply_suggestion", "nb_revert_cell", "nb_clear_outputs", "nb_open", "nb_list", "nb_set_cwd"];
    readonly search: readonly ["glob", "grep", "swarm_project_files"];
    readonly edit: readonly ["write", "edit", "nb_save"];
    readonly shell: readonly ["pwsh", "bash"];
    readonly web: readonly ["web_search", "web_fetch"];
    readonly jev: readonly ["jev_ask", "jev_check", "jev_classify", "jev_health", "jev_match", "jev_score", "jev_screen"];
    readonly calculate: readonly ["swarm_calculate", "nb_run_cell", "nb_run_all", "nb_edit_and_run_cell", "nb_kernel_restart", "nb_kernel_restart_and_run_all", "nb_kernel_restart_and_clear", "nb_kernel_interrupt", "nb_kernel_select"];
    readonly context: readonly ["swarm_context_read"];
    readonly message: readonly ["swarm_message_send", "swarm_message_read", "swarm_message_ack"];
};
/** 角色能力名 */
export type Capability = keyof typeof CAPABILITY_TOOL_CANDIDATES;
/** 视为写文件的工具名，守卫据此拒绝只读类角色 */
export declare const WRITE_TOOL_NAMES: readonly string[];
/** 会话头中本插件读取的字段 */
export interface SessionHeaderLike {
    parentSession?: string;
    agentPreset?: string;
    cwd?: string;
}
/** Agent 的最小形状 */
export interface AgentLike {
    id: string;
    session?: {
        header?: SessionHeaderLike;
        deriveMessages?: () => readonly {
            id?: string;
            role?: string;
            source?: {
                kind?: string;
                callId?: string;
                outcome?: string;
            };
            toolCallId?: string;
            isError?: boolean;
            content?: readonly ContentBlockLike[];
        }[];
        surface?: {
            replaceGeneration: number;
        };
        requestHeader?: () => {
            config: CallConfigLike;
        } | undefined;
    };
}
/** Real DSH compaction seam; progress is verified against the durable surface generation. */
export interface ContextCompactionLike {
    compactIfNeeded: (agent: AgentLike, trigger: 'context-overflow', signal: AbortSignal) => Promise<unknown | null>;
}
/** LLM 失败信息 */
export interface LlmFailureLike {
    code?: string;
    status?: number;
    message?: string;
    providerRetryAfterMs?: number;
    requestId?: string;
    kind?: string;
    quotaDomainId?: string;
    quotaScope?: 'account' | 'plan' | 'model' | 'pool' | 'unknown';
    poolId?: string;
    resetAt?: string;
}
/** 一次模型调用的路由配置 */
export interface CallConfigLike {
    provider: string;
    model: string;
    reasoningEffort?: string;
    maxTokens?: number;
    [key: string]: unknown;
}
/** 消息内容块 */
export interface ContentBlockLike {
    type: string;
    text?: string;
    [key: string]: unknown;
}
/** 子智能体结果 */
export interface SubagentResultLike {
    output: ContentBlockLike[];
    structured?: unknown;
    diagnostic?: string;
    stopReason: string;
}
/** 子智能体运行句柄 */
export interface SubagentRunLike {
    id: string;
    result: Promise<SubagentResultLike>;
    dispose: () => Promise<void>;
}
/** DSH 0.2.1-alpha 起的一次激活：本地子会话固定为连续会话，结算后由调用方 dispose 实现一次性语义 */
export interface SubagentActivationLike {
    name?: string;
    childId: string;
    messageId?: string;
    result: Promise<SubagentResultLike>;
    dispose: () => Promise<void>;
}
/** 激活启动请求（0.2.1-alpha 起）：composition 由 agentPreset 选择的预设负责，不再接受 persona/toolFilter */
export interface SubagentActivationSpecLike {
    provider: string;
    label: string;
    childId?: string;
    name?: string;
    prompt?: ContentBlockLike[];
    parent?: AgentLike;
    agentOptions?: SubagentStartRequestLike['agentOptions'];
    outputSchema?: object;
    maxDepth?: number;
    agentPreset?: string;
    request?: Omit<SubagentStartRequestLike, 'label' | 'signal' | 'toolFilter' | 'persona'>;
    signal: AbortSignal;
    delivery: 'parent' | 'caller';
}
/** 一次性子智能体启动请求 */
export interface SubagentStartRequestLike {
    label?: string;
    prompt: ContentBlockLike[];
    parent: AgentLike;
    signal: AbortSignal;
    agentOptions?: {
        provider: string;
        model: string;
        reasoningEffort?: string;
    };
    outputSchema?: object;
    maxDepth?: number;
    toolFilter?: {
        allow?: string[];
        deny?: string[];
    };
    persona?: string;
}
/** 连续会话（continuable）子智能体的创建请求：不支持 outputSchema，结构化结果由子智能体以 json 代码块回复 */
export interface ContinuableStartSpecLike {
    provider: string;
    label: string;
    /** 调用方预留的子会话 ID：先登记等待者与路由状态，再创建，避免错过首轮结束事件 */
    childId?: string;
    request: Omit<SubagentStartRequestLike, 'label' | 'signal' | 'outputSchema'>;
    signal: AbortSignal;
}
/** rc.3 用 runId 标识驻留激活；旧宿主仅提供 child id。 */
export interface SubagentRunInfoLike {
    runId?: string;
    provider?: string;
    parentSessionId?: string;
    local?: boolean;
    id: string;
}
/** 子智能体一轮结束（subagent/end）；连续会话每次沉寂都会发出一次 */
export interface SubagentEndInfoLike extends SubagentRunInfoLike {
    stopReason: string;
    lastAssistantMessage?: readonly ContentBlockLike[];
    /** Host turn/end error text captured from session/event; absent when the host did not expose one. */
    diagnostic?: string;
}
/** ctx.subagents 的最小形状；连续会话相关方法在 DSH 0.1.7-rc.2 起提供，缺失时退回一次性委派 */
export interface SubagentsLike {
    /** 0.2.0-rc.2 及更早的启动入口；0.2.1-alpha 起由 startActivation 取代 */
    start?: (name: string, request: SubagentStartRequestLike) => Promise<SubagentRunLike>;
    startActivation?: (spec: SubagentActivationSpecLike) => Promise<SubagentActivationLike>;
    getProvider: (name: string) => {
        capabilities?: Record<string, boolean>;
    } | undefined;
    list?: () => string[];
    startContinuable?: (spec: ContinuableStartSpecLike) => Promise<{
        childId: string;
        messageId: string;
    }>;
    sendMessage?: (sender: AgentLike, targetId: string, content: ContentBlockLike[], options: {
        signal: AbortSignal;
    }) => Promise<string>;
    interrupt?: (targetSessionId: string, authority: {
        kind: 'ancestor';
        agent: AgentLike;
    }) => void;
    listDescendants?: (rootSessionId: string, signal?: AbortSignal) => Promise<Array<{
        id: string;
        parentId: string;
        depth: number;
        kind: 'child' | 'diagnostic';
        mode?: 'continuable' | 'one-shot' | 'external';
        name?: string;
        path?: string;
        activity?: 'inactive' | 'running';
        hasChildren?: boolean;
    }>>;
    listChildren?: (parentSessionId: string, signal?: AbortSignal) => Promise<Array<{
        id: string;
        createdAt: number;
        mode: 'continuable' | 'one-shot' | 'unknown';
        label?: string;
    }>>;
}
/** ctx.jobs 的最小形状：会话启动的后台作业（长时间构建、代码生成等），owner 为启动它的会话 ID */
export interface JobsLike {
    list: (caller: string) => Array<{
        id: string;
        owner?: string;
        status: string;
    }>;
    kill: (id: string, caller: string, reason?: string) => unknown;
    /** 等到终态或超时，返回当时的作业状态 */
    wait: (id: string, timeoutMs: number, caller: string) => Promise<{
        status: string;
    }>;
}
/** session/event 的后台作业事实；强制失败/拒绝不是 producer done 的清理确认。 */
export interface JobLifecycleEventLike {
    type: string;
    data?: {
        jobId?: string;
        owner?: string;
        status?: string;
        producerReported?: boolean;
        reason?: {
            kind?: string;
            error?: {
                message?: string;
                code?: string;
            } | string;
        };
    };
}
/** 进入一步之前的消息（agent/pre-step）；只读取本插件需要的来源字段 */
export interface InboxMessageLike {
    source?: {
        kind?: string;
        senderSessionId?: string;
    };
    [key: string]: unknown;
}
/** agent/pre-step 的决定 */
export type PreStepDecisionLike = {
    kind: 'reject';
} | {
    kind: 'enter';
    messages: InboxMessageLike[];
    [key: string]: unknown;
};
/** ctx.llm 的最小形状 */
export interface LlmLike {
    listProviders: () => Array<{
        id: string;
    }>;
    resolveModelInfo: (provider: string, model: string, signal?: AbortSignal) => Promise<{
        inputModalities?: readonly string[];
        reasoning?: {
            efforts: readonly {
                id: string;
                name?: string;
            }[];
            defaultEffort?: string;
        };
        context?: {
            contextWindow?: number;
        };
        defaultMaxTokens?: number;
    }>;
    resolveCallConfig?: (config: Pick<CallConfigLike, 'provider' | 'model' | 'reasoningEffort'>, signal?: AbortSignal) => Promise<CallConfigLike>;
    stream?: (options: {
        provider: string;
        model: string;
        reasoningEffort?: string;
        system?: string;
        messages: Array<{
            role: 'user';
            content: ContentBlockLike[];
        }>;
        signal?: AbortSignal;
    }) => AsyncIterable<Record<string, unknown>>;
}
/** DSH token-meter seam used only for bounded route admission. */
export interface TokenMeterLike {
    measure: (session: unknown) => {
        totalTokens: number;
    };
}
/** 工具守卫看到的执行信息 */
export interface ToolExecutionLike {
    name: string;
    arguments?: unknown;
    agent?: AgentLike;
    callId?: string;
    signal?: AbortSignal;
}
/** DSH 0.2 ToolRuntime pre-dispatch waterfall; an ask is resolved by ctx.approval. */
export type PreToolDecisionLike = {
    kind: 'allow';
} | {
    kind: 'deny';
    reason: string;
    info?: {
        name: string;
        code: string;
        reason?: string;
    };
} | {
    kind: 'cancel';
} | {
    kind: 'ask';
    reason?: string;
    displayReason?: {
        en: string;
        [locale: string]: string;
    };
};
export type ApprovalOutcomeLike = 'allowed-once' | 'rejected' | 'cancelled' | 'unavailable';
/** Public approval capability. Policy mutation is intentionally not part of the plugin contract. */
export interface ApprovalServiceLike {
    config?: {
        policy?: 'ask' | 'never';
    };
    overrideOf?: (session: NonNullable<AgentLike['session']>) => 'ask' | 'never' | undefined;
    request: (request: {
        agent: AgentLike;
        toolName: string;
        callId?: string;
        reason?: string;
        signal?: AbortSignal;
    }) => Promise<ApprovalOutcomeLike>;
}
/** ctx.tools 的最小形状 */
export interface ToolsLike {
    register: (definition: unknown) => () => void;
    schemas: (scope?: unknown) => Array<{
        name: string;
    }>;
    guard: (guard: (execution: ToolExecutionLike) => string | undefined) => () => void;
}
/** ctx.attachments 的最小形状 */
export interface AttachmentsLike {
    saveImages: (inputs: Array<{
        data: Uint8Array;
        mediaType: string;
        name?: string;
    }>) => Promise<readonly unknown[]>;
}
/** ctx.credentials 的最小形状；describe 只返回是否已配置与来源，不返回密钥值 */
export interface CredentialsLike {
    resolve: (ref: string) => Promise<{
        value: string;
        source?: string;
    } | undefined>;
    describe?: (ref: string) => Promise<{
        configured: boolean;
        source?: string;
        writable: boolean;
    }>;
}
/** ctx.skills 的最小形状（DSH 0.2.0 起）：在调用方作用域注册运行时技能 */
export interface SkillsLike {
    register: (skill: {
        name: string;
        description: string;
        content: string;
        source: string;
        path?: string;
    }) => () => void;
}
/** system-prompt/assemble 瀑布的组装结果中本插件读写的部分 */
export interface PromptAssemblyLike {
    sections: Array<{
        name: string;
        text: string;
        interpolate?: boolean;
    }>;
    variables: Record<string, string | undefined>;
    [key: string]: unknown;
}
/** Public dynamic context seam; rc.3 refreshes it after each actual route admission. */
export interface SystemPromptLike {
    context: (entry: {
        name: string;
        order: number;
        required?: boolean;
        interpolate?: boolean;
        text: (context: {
            agent?: AgentLike;
        }) => string;
    }) => () => void;
    refreshContext?: (...args: unknown[]) => unknown;
}
/** 宿主 connection.fetch.register 接受的路由（与 dsh-plugin-subscriptions 相同的 RPC 线格式） */
export interface FetchRouteLike {
    path: string;
    methods: string[];
    requestBody: 'buffered';
    fetch: (request: Request) => Promise<Response>;
}
/** ctx.connection 的最小形状 */
export interface ConnectionLike {
    /** Public Host carrier for trusted, already-authenticated internal calls. */
    createSharedFetchHandler?: (channel: '/api') => {
        fetch: (request: Request, peer?: unknown) => Promise<Response>;
    };
    /** 0.2.1-alpha 起：为进程内受信调用创建一个被准入的 Peer；旧宿主没有该能力。 */
    createPeer?: (options: {
        principal: {
            kind: 'owner';
        };
    }) => unknown;
    fetch: {
        register: (route: FetchRouteLike) => () => void;
    };
}
/** ctx.sessionProjections 的最小形状：会话在空白期切换预设后，当前预设只在 agentPreset 投影里，会话头仍是创建时的值 */
export interface SessionProjectionsLike {
    stateOf: (session: unknown, key: string) => unknown;
}
/** Public DSH goal lifecycle; disarm changes process-local activation, not durable phase. */
export interface GoalRefLike {
    id: string;
    revision: number;
}
export interface GoalViewLike extends GoalRefLike {
    phase: 'active' | 'paused' | 'blocked' | 'complete';
    activation: 'armed' | 'disarmed';
    roundsStarted: number;
    maxGoalRounds: number;
}
export interface GoalsLike {
    get: (agent: AgentLike) => GoalViewLike | undefined;
    disarm: (agent: AgentLike) => GoalViewLike | undefined;
    resume?: (agent: AgentLike, ref: GoalRefLike) => GoalViewLike;
}
/** Optional public question service used for capability diagnostics; no permission mutation. */
export interface UserQuestionsLike {
    continued?: (agent: AgentLike) => readonly {
        callId: string;
        state: string;
        questions: readonly unknown[];
    }[];
}
/** agent/request-error 的载荷；signal 为本轮的取消信号（DSH 0.2.0 起提供） */
export interface RequestErrorPayloadLike {
    agent: AgentLike;
    /** Actual Host request position; older adapters may omit it. */
    turn?: number;
    step?: number;
    provider: string;
    failure: LlmFailureLike;
    signal?: AbortSignal;
}
/** agent/request-error 的动作；undefined 表示失败终止 */
export type RequestErrorActionLike = {
    kind: string;
} | undefined;
/** Cordis 插件上下文中本插件用到的部分 */
export interface PluginContextLike {
    get: (name: string) => unknown;
    provide: (name: string, value?: unknown) => () => void;
    effect: (execute: () => () => void) => unknown;
    on: (name: string, listener: (...args: never[]) => unknown, options?: {
        prepend?: boolean;
    }) => unknown;
    /** 可选依赖：服务就绪后在子上下文中执行（无界面的 profile 没有 connection） */
    inject?: (deps: string[], callback: (ctx: PluginContextLike) => void) => unknown;
    logger?: (name: string) => {
        info: (...args: unknown[]) => void;
        warn: (...args: unknown[]) => void;
    };
}
/**
 * 读取 agent 会话头
 * @param {AgentLike | undefined} agent - 宿主 agent
 * @returns {SessionHeaderLike} 会话头，缺失时为空对象
 */
export declare const getAgentHeader: (agent: AgentLike | undefined) => SessionHeaderLike;
