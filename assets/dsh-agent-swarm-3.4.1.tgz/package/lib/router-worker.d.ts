export declare const EVENT_FILTER_REASONS: readonly ['duplicate', 'self-echo', 'ignored-kind', 'stale-request-revision', 'stale-card-revision', 'stale-workflow-revision', 'stale-lease'];
export type EventFilterReason = typeof EVENT_FILTER_REASONS[number];
export interface EventFilterInput {
    eventId: string;
    idempotencyKey?: string;
    kind: string;
    senderAgentId?: string;
    rootAgentId: string;
    ignoredKinds?: readonly string[];
    requestRevision: number;
    cardRevision: number;
    workflowRevision: number;
    leaseEpoch: number;
    current: {
        requestRevision: number;
        cardRevision: number;
        workflowRevision: number;
        leaseEpoch: number;
    };
    seen: {
        has(key: string): boolean;
    };
}
export type EventFilterResult = {
    accepted: true;
} | {
    accepted: false;
    reason: EventFilterReason;
};
/** Filter host events before they can mutate a ticket or start a model call. */
export declare const filterEvent: (input: EventFilterInput) => EventFilterResult;
export declare const ROUTER_DENIED_TOOLS: Set<string>;
/** The router may route and read evidence; host denial and writes stay with workers. */
export declare const getRouterToolDenial: (toolName: string, argumentsValue?: unknown) => string | undefined;
export interface AssignmentEnvelope {
    ticketId: string;
    assignmentId: string;
    role: string;
    workerKind: 'expert' | 'native-codex' | 'native-claude';
    provider: string;
    model: string;
    reasoningEffort?: string;
    requestRevision: number;
    cardRevision: number;
    workflowRevision: number;
    leaseEpoch: number;
    inputDigest: string;
    permissions: readonly string[];
    createdAt: number;
}
export interface WorkerSubmission {
    ticketId: string;
    assignmentId: string;
    requestRevision: number;
    cardRevision: number;
    workflowRevision: number;
    leaseEpoch: number;
    inputDigest: string;
}
export type WorkerSubmissionResult = {
    accepted: true;
} | {
    accepted: false;
    reason: 'ticket-mismatch' | 'assignment-mismatch' | 'stale-request-revision' | 'stale-card-revision' | 'stale-workflow-revision' | 'stale-lease' | 'input-mismatch';
};
export declare const ValidateAssignmentEnvelope: (value: unknown) => value is AssignmentEnvelope;
export declare const validateWorkerSubmission: (envelope: AssignmentEnvelope, submission: WorkerSubmission) => WorkerSubmissionResult;
