import { type Capability } from './host-contract.js';
import { type OutputLanguage } from './language.js';
import { type PromptStyle } from './model-family.js';
/** 13 个角色的稳定 ASCII ID（天枢 + 12 个可委派角色） */
export declare const ROLE_IDS: readonly ['tian_shu', 'mou_ding', 'shu_ji', 'suan_heng', 'tan_wei', 'bo_wen', 'guan_xiang', 'zhu_jian', 'xing_zhou', 'ji_feng', 'yu_shi', 'fu_he', 'miao_bi'];
export type RoleId = typeof ROLE_IDS[number];
export type DelegableRoleId = Exclude<RoleId, 'tian_shu'>;
export type PermissionLevel = 'orchestrator' | 'read' | 'limited-exec' | 'verify' | 'workspace-edit';
export type WebPolicy = 'always' | 'on-request' | 'never';
export type SuanHengMode = 'research' | 'verify';
/** 角色定义：职责、边界、触发、交付、权限与工具能力 */
export interface RoleInfo {
    id: RoleId;
    presetId: string;
    name: string;
    title: string;
    duty: string;
    boundaries: readonly string[];
    triggers: readonly string[];
    deliverables: readonly string[];
    permission: PermissionLevel;
    capabilities: readonly Capability[];
    web: WebPolicy;
    needsVision: boolean;
    concurrencySafe: boolean;
    order: number;
}
export declare const ROLE_INFO_LIST: readonly RoleInfo[];
/**
 * 角色适用的工程规范（含语言要求）
 * @param {RoleId} id - 角色
 * @param {OutputLanguage} [language] - 给出时直接写入语言名称；省略时保留占位符，由 runtime 行替换
 * @returns {string[]} 规范，每条一行
 */
export declare const getRoleRules: (id: RoleId, language?: OutputLanguage | null) => string[];
/** 子智能体 persona 中的机器可读角色标签 */
export declare const ROLE_TAG_PATTERN: RegExp;
export declare const isRoleId: (value: unknown) => value is RoleId;
export declare const isDelegableRoleId: (value: unknown) => value is DelegableRoleId;
/**
 * 按 ID 取角色定义
 * @param {RoleId} id - 角色 ID
 * @returns {RoleInfo} 角色定义
 */
export declare const getRoleInfo: (id: RoleId) => RoleInfo;
/**
 * 按预设 ID 查找角色
 * @param {string | undefined} presetId - 会话头中的 agentPreset
 * @returns {RoleInfo | undefined} 角色定义，非 swarm 预设返回 undefined
 */
export declare const FindRoleByPresetId: (presetId: string | undefined) => RoleInfo | undefined;
export declare const getDelegableRoleIds: () => DelegableRoleId[];
/** Semantic capability hints are separate from Host tool permissions. */
export declare const ROLE_CAPABILITY_TAGS: Readonly<Record<DelegableRoleId, readonly string[]>>;
export declare const getRoleCapabilityTags: (id: DelegableRoleId) => readonly string[];
/** Suggestions never change the requested role, allowed tools or mandatory workflow gates. */
export declare const suggestRolesByCapabilities: (tags: readonly string[], options?: {
    allowWrite?: boolean;
}) => Array<{
    role: DelegableRoleId;
    tags: readonly string[];
}>;
export declare const isEditRole: (id: RoleId) => boolean;
export declare const isWriteAllowed: (id: RoleId) => boolean;
export declare const getPermissionLabel: (id: RoleId) => string;
/**
 * 计算角色希望使用的宿主工具名（调用时再与实际可见工具求交集）
 * @param {RoleId} id - 角色 ID
 * @param {{ allowWeb?: boolean }} [options] - 本次委派是否开放 web
 * @returns {string[]} 候选工具名
 */
export declare const getWantedTools: (id: RoleId, options?: {
    allowWeb?: boolean;
}) => string[];
export declare const getRoleTag: (id: RoleId) => string;
/**
 * 生成被委派子智能体的 persona，按模型家族组织（Claude：XML 分节；GPT：目标/约束/停止规则；其他：编号必做项）
 * @param {DelegableRoleId} id - 角色 ID
 * @param {SuanHengMode} [mode] - 算衡模式
 * @param {PromptStyle} [style='generic'] - 提示风格
 * @param {OutputLanguage} [language] - 输出语言；省略时保留 {$language} 占位符
 * @returns {string} persona 文本
 */
export declare const getChildPersona: (id: DelegableRoleId, mode?: SuanHengMode, style?: PromptStyle, language?: OutputLanguage | null) => string;
/**
 * 生成天枢工具说明中使用的角色目录（每行一个可委派角色）
 * @returns {string} 角色目录文本
 */
export declare const getRoleCatalogText: () => string;
/**
 * 生成预设（用户直接选用的会话）的 persona 前缀
 * @param {RoleId} id - 角色 ID
 * @returns {string} persona 文本，只使用 {{model}} 变量
 */
export declare const getPresetPersona: (id: RoleId) => string;
