/** 插件内部错误码 */
export type SwarmErrorCode = 'INVALID_ARGS' | 'UNKNOWN_TASK' | 'UNKNOWN_ROLE' | 'INVALID_TRANSITION' | 'PATH_OUTSIDE_WORKSPACE' | 'UNSUPPORTED_IMAGE' | 'SERVICE_UNAVAILABLE' | 'BUDGET_EXHAUSTED' | 'CAPACITY_EXCEEDED' | 'PLANNING_REVIEW_REQUIRED' | 'STALE_EVIDENCE' | 'CONTEXT_REFERENCE_UNAVAILABLE' | 'CONTEXT_RECOVERY_REQUIRED' | 'PERMISSION_DENIED' | 'RECOVERY_REQUIRED';
/** 带稳定错误码的插件错误，工具层把它转成模型可读的错误结果 */
export declare class SwarmError extends Error {
    readonly code: SwarmErrorCode;
    constructor(code: SwarmErrorCode, message: string);
}
/**
 * 取错误的可读文本
 * @param {unknown} error - 任意抛出值
 * @returns {string} 错误消息
 */
export declare const getErrorText: (error: unknown) => string;
