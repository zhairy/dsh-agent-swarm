/**
 * Optional legacy invariant companion. DSH 0.2.1 removed this service.
 * The upstream installer had no checks, so absence needs no replacement check.
 */
import type { Context } from '@deepseek-ai/cordis'

interface LegacyInvariantService {
  register(packageName: string, install: () => void): (() => void) | Promise<() => void>
}
interface LegacyLookup { get(name: string): LegacyInvariantService | undefined }

export const name = 'calculator-invariant'
export const inject: string[] = []

export const apply = (ctx: Context): Promise<() => void> => {
  const legacy = (ctx as unknown as LegacyLookup).get('invariants')
  return legacy === undefined
    ? Promise.resolve(() => {})
    : Promise.resolve(legacy.register('@deepseek-ai/dsh-tool-calculator', () => {}))
}
