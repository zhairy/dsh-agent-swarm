import { apply as applyPiAi, Config, inject, name } from './native-pi-ai.mjs';

export { Config, inject, name };

const RESERVED_PROVIDERS = new Set(['opencode', 'opencode-go']);

/** 保留原生注册的原子 replace，只隔离 OpenCode 专用插件拥有的路由。 */
export const createProviderRegistration = (ctx, register, entries, providerOf, args = []) => {
  let registration;
  let isDisposed = false;
  const replace = (next) => {
    if (isDisposed) throw new Error('API provider registration has been disposed');
    const selected = next.filter((entry) => !RESERVED_PROVIDERS.has(providerOf(entry)));
    try {
      if (registration) registration.replace(selected);
      else if (selected.length > 0) registration = register(selected, ...args);
    } catch (error) {
      ctx.logger.warn(`API provider registration failed: ${error.code ?? error.name ?? 'unknown'}`);
      throw error;
    }
  };
  const dispose = () => {
    if (isDisposed) return;
    isDisposed = true;
    registration?.();
  };
  replace(entries);
  // 原生 handle 由 fiber 管理；此 effect 也关闭空集合时期的延迟注册入口。
  ctx.effect(() => dispose);
  return Object.assign(dispose, { replace });
};

/** 使用原生 API 设置能力，避免它覆盖 OpenCode 的动态发现和专用协议。 */
export const createProviderSettingsContext = (ctx) => {
  const llm = ctx.llm;
  const filteredLlm = new Proxy(llm, {
    get(target, key) {
      const value = Reflect.get(target, key, target);
      if (key === 'registerAdapter') {
        return (providers, adapter) => createProviderRegistration(ctx, value.bind(target), providers, (provider) => provider, [adapter]);
      }
      if (key === 'registerConfigurableProviders') {
        return (entries) => createProviderRegistration(ctx, value.bind(target), entries, (entry) => entry.provider);
      }
      return typeof value === 'function' ? value.bind(target) : value;
    }
  });
  return ctx.extend({ llm: filteredLlm });
};

export const apply = (ctx, config) => applyPiAi(createProviderSettingsContext(ctx), config);
