import { readFile, writeFile, mkdir, rename, rm } from 'node:fs/promises';
import { dirname } from 'node:path';
import { randomUUID } from 'node:crypto';

export const LISTING_URL = 'https://opencode.ai/zen/v1/models';
export const METADATA_URL = 'https://models.dev/api.json';
export const GO_LISTING_URL = 'https://opencode.ai/zen/go/v1/models';
const APIS = new Set(['openai-completions', 'openai-responses', 'anthropic-messages', 'google-generative-ai']);
const positive = (n) => Number.isSafeInteger(n) && n > 0;
const officialEndpoint = (raw) => {
  try {
    const url = new URL(raw);
    return url.protocol === 'https:' && url.hostname === 'opencode.ai' && !url.username && !url.password && !url.search && !url.hash && (!url.port || url.port === '443');
  } catch { return false; }
};

export const parseListing = (body) => {
  if (!Array.isArray(body?.data)) throw new Error('OpenCode model listing has no data array');
  const ids = [...new Set(body.data.map((m) => m?.id).filter((id) => typeof id === 'string' && /^[a-zA-Z0-9._-]+$/.test(id)))];
  if (!ids.length) throw new Error('OpenCode returned an empty model listing; retaining the previous catalog');
  return ids;
};

const metadataApi = (row) => {
  const source = row?.provider ?? {};
  if (source.npm === '@ai-sdk/google' || /\/google\/v1beta\/?$/.test(source.api ?? '')) return 'google-generative-ai';
  if (source.npm === '@ai-sdk/anthropic' || /\/anthropic(?:\/v1)?\/?$/.test(source.api ?? '')) return 'anthropic-messages';
  if (/\/openai\/v1\/?$/.test(source.api ?? '') || source.npm === '@ai-sdk/openai-compatible') return 'openai-completions';
  return undefined;
};

/** Live IDs decide membership; independent metadata decides whether a model is safe to call. */
export const buildCatalog = (ids, metadata, builtin, provider = 'opencode') => {
  const result = new Map();
  const unavailable = [];
  const rows = metadata?.[provider]?.models ?? {};
  for (const id of ids) {
    const known = builtin.get(id);
    const row = rows[id];
    const api = known?.api ?? metadataApi(row);
    // Metadata is descriptive data; it must never redirect the user's credential to another origin.
    if (!officialEndpoint(row?.provider?.api ?? known?.baseUrl)) {
      unavailable.push(id);
      continue;
    }
    if (!APIS.has(api) || row?.tool_call === false || (row?.modalities?.output && !row.modalities.output.includes('text'))) {
      unavailable.push(id);
      continue;
    }
    const contextWindow = row?.limit?.context ?? known?.contextWindow;
    const maxTokens = row?.limit?.output ?? known?.maxTokens;
    if (!positive(contextWindow) || !positive(maxTokens) || (!known && row?.tool_call !== true)) {
      unavailable.push(id);
      continue;
    }
    const input = (row?.modalities?.input ?? known?.input ?? []).filter((m) => m === 'text' || m === 'image');
    if (!input.includes('text') || (!known && !row?.provider?.api)) {
      unavailable.push(id);
      continue;
    }
    const model = {
      ...known, id, provider, api, type: 'chat',
      name: row?.name ?? known?.name ?? id,
      baseUrl: row?.provider?.api ?? known?.baseUrl,
      contextWindow, maxTokens, input,
      reasoning: row?.reasoning ?? known?.reasoning ?? false,
      cost: known?.cost ?? { input: row?.cost?.input ?? 0, output: row?.cost?.output ?? 0, cacheRead: row?.cost?.cache_read ?? 0, cacheWrite: row?.cost?.cache_write ?? 0 }
    };
    // A new reasoning family needs an explicit wire mapping; never borrow a similarly named model's settings.
    if (!known && model.reasoning) {
      const efforts = (row.reasoning_options ?? []).find((o) => o.type === 'effort')?.values;
      if (!Array.isArray(efforts) || !['openai-completions', 'google-generative-ai'].includes(api)) {
        unavailable.push(id);
        continue;
      }
      model.thinkingLevelMap = Object.fromEntries(['off', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max'].map((level) => [level, efforts.includes(level) ? level : null]));
      if (api === 'openai-completions') model.compat = { supportsReasoningEffort: true, ...(row.interleaved ? { reasoningContentField: row.interleaved.field } : {}) };
    }
    result.set(id, model);
  }
  return { models: result, unavailable };
};

/** Configuration is an explicit allowlist, independent of refresh and discovery. */
export const selectModels = (catalog, entries = []) => entries.map((entry) => {
  const model = catalog.models.get(entry.id);
  if (!model) throw new Error(`OpenCode model ${entry.id} is unavailable or lacks verified protocol metadata; refresh the catalog`);
  const selected = { ...model, input: [...model.input] };
  for (const field of ['contextWindow', 'maxTokens']) {
    if (entry[field] === undefined) continue;
    if (!positive(entry[field]) || entry[field] > model[field]) throw new Error(`OpenCode ${entry.id}: ${field} exceeds catalog limit ${model[field]}`);
    selected[field] = entry[field];
  }
  if (typeof entry.name === 'string' && entry.name.length) selected.name = entry.name;
  if (entry.maxTokens !== undefined && entry.maxTokens >= selected.contextWindow) throw new Error(`OpenCode ${entry.id}: output budget must be below context capacity`);
  return selected;
});

export const fetchJson = async (url, maxBytes, signal, fetcher = fetch) => {
  const response = await fetcher(url, {
    headers: { accept: 'application/json', 'user-agent': 'dsh-opencode-live/0.1.0' },
    signal: AbortSignal.any([AbortSignal.timeout(30000), ...(signal ? [signal] : [])])
  });
  if (!response.ok) throw new Error(`${new URL(url).host}: HTTP ${response.status}`);
  if (Number(response.headers.get('content-length')) > maxBytes) throw new Error('OpenCode catalog response exceeds size limit');
  const chunks = [];
  let size = 0;
  for await (const chunk of response.body) {
    size += chunk.byteLength;
    if (size > maxBytes) throw new Error('OpenCode catalog response exceeds size limit');
    chunks.push(chunk);
  }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
};

export const readCache = async (path, logger, provider = 'opencode') => {
  try {
    const value = JSON.parse(await readFile(path, 'utf8'));
    parseListing(value.listing);
    if (value.version !== 1 || !value.metadata?.[provider]?.models || !positive(value.updatedAt)) throw new Error('Invalid OpenCode cache schema');
    return value;
  } catch (error) {
    if (error.code !== 'ENOENT') logger.warn(`OpenCode cache ${path}: ${error.message}`);
    return undefined;
  }
};

export const writeCache = async (path, value) => {
  const temp = `${path}.${process.pid}.${randomUUID()}.tmp`;
  try {
    await mkdir(dirname(path), { recursive: true, mode: 0o700 });
    await writeFile(temp, JSON.stringify(value), { mode: 0o600, flag: 'wx' });
    await rename(temp, path);
  } finally {
    await rm(temp, { force: true });
  }
};

export class LiveCatalog {
  constructor({ builtin, cachePath, logger, fetcher = fetchJson, onRefresh = () => {}, provider = 'opencode' }) {
    Object.assign(this, { builtin, cachePath, logger, fetcher, onRefresh, provider });
    this.value = { models: new Map(builtin), unavailable: [] };
    this.updatedAt = 0;
  }
  async initialize() {
    const cached = await readCache(this.cachePath, this.logger, this.provider);
    if (cached) {
      this.value = buildCatalog(parseListing(cached.listing), cached.metadata, this.builtin, this.provider);
      this.updatedAt = cached.updatedAt;
    }
  }
  refresh(signal) {
    if (this.pending) return this.pending;
    this.pending = this.update(signal).finally(() => { this.pending = undefined; });
    return this.pending;
  }
  async update(signal) {
    const [listing, metadata] = await Promise.all([
      this.fetcher(this.provider === 'opencode-go' ? GO_LISTING_URL : LISTING_URL, 1024 * 1024, signal),
      this.fetcher(METADATA_URL, 16 * 1024 * 1024, signal)
    ]);
    if (!metadata?.[this.provider]?.models) throw new Error('models.dev has no OpenCode metadata; retaining previous catalog');
    const next = buildCatalog(parseListing(listing), metadata, this.builtin, this.provider);
    if (!next.models.size) throw new Error('No usable OpenCode models; retaining previous catalog');
    signal?.throwIfAborted();
    const updatedAt = Date.now();
    // Persistence succeeds before publication, so failed disk I/O never advertises a durable refresh.
    await writeCache(this.cachePath, { version: 1, listing, metadata: { [this.provider]: metadata[this.provider] }, updatedAt });
    signal?.throwIfAborted();
    this.value = next;
    this.updatedAt = updatedAt;
    this.onRefresh();
    return next;
  }
}
