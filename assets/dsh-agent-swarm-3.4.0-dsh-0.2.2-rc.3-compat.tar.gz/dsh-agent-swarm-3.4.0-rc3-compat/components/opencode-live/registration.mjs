/** Keep no adapter registered while the configured provider set is empty. */
export const createDynamicRegistration = (register) => {
  let current
  let disposed = false
  const replace = (providers) => {
    if (disposed) throw new Error('OpenCode adapter registration is disposed')
    if (!Array.isArray(providers) || providers.some(provider => typeof provider !== 'string' || provider === '')) throw new Error('Invalid OpenCode provider set')
    if (providers.length === 0) {
      current?.()
      current = undefined
    } else if (current) current.replace(providers)
    else current = register(providers)
  }
  const dispose = () => {
    if (disposed) return
    disposed = true
    current?.()
    current = undefined
  }
  return { replace, dispose }
}
