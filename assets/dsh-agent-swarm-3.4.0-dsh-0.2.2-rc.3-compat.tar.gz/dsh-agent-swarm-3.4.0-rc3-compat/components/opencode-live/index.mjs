import Schema from '@deepseek-ai/schemastery';
import { PiAiAdapter } from './native-pi-ai.mjs';
import { LlmError, resolveRetryPolicy, assertUsableApiKey, resolveImageAttachmentAccess } from '@deepseek-ai/dsh-llm';
import { credentialRef } from '@deepseek-ai/dsh-credentials';
import { launchEnvironmentOf } from '@deepseek-ai/dsh-launch-environment';
import { opencodeProvider } from '@earendil-works/pi-ai/providers/opencode';
import { opencodeGoProvider } from '@earendil-works/pi-ai/providers/opencode-go';
import { LiveCatalog, selectModels } from './catalog.mjs';
import { createDynamicRegistration } from './registration.mjs';
import { homedir } from 'node:os';
import { join } from 'node:path';

export const name = 'opencode-live';
export const inject = ['llm'];
const modelSchema = Schema.object({
  id: Schema.string().required(), name: Schema.string(),
  contextWindow: Schema.natural().min(1), maxTokens: Schema.natural().min(1)
});
const profileSchema = Schema.object({
  apiKeyEnv: Schema.string().role('credential-ref').default('OPENCODE_API_KEY'),
  displayName: Schema.string().default('OpenCode Zen'),
  models: Schema.array(modelSchema).default([]),
  streamIdleTimeoutMs: Schema.natural().min(1000).max(2147483647).default(300000)
});
export const Config = Schema.object({
  providers: Schema.dict(profileSchema).default({}).volatile(),
  refreshMinutes: Schema.natural().min(1).max(1440).default(60).volatile()
});

export const createProfiles = (providers, catalogs, natives, strict = true) => {
  const profiles = new Map();
  for (const [provider, input] of Object.entries(providers)) {
    const catalog = catalogs.get(provider);
    const native = natives.get(provider);
    if (!catalog || !native) throw new Error(`OpenCode live plugin does not own ${provider}`);
    const errors = new Map();
    const models = (input.models ?? []).flatMap((entry) => {
      try { return selectModels(catalog, [entry]); }
      catch (error) { if (strict) throw error; errors.set(entry.id, error.message); return []; }
    });
    profiles.set(provider, {
      provider, displayName: input.displayName ?? 'OpenCode Zen',
      apiKeyEnv: credentialRef(input.apiKeyEnv ?? 'OPENCODE_API_KEY'),
      streamIdleTimeoutMs: input.streamIdleTimeoutMs ?? 300000,
      maxRequestImageBytes: 20971520, requestImagePixelBudget: 4194304, requestImageMaxBytes: 1048576,
      retryPolicy: resolveRetryPolicy(undefined, 'opencode-live'),
      modelErrors: errors, configuredMaxTokens: new Map(models.map((model) => [model.id, input.models?.find((entry) => entry.id === model.id)?.maxTokens ?? Math.min(model.maxTokens, 32768)])),
      // Native dispatch chooses the protocol per model, retaining OpenCode's stable session headers.
      piProvider: { ...native, id: provider, name: input.displayName ?? 'OpenCode Zen', getModels: () => models }
    });
  }
  return profiles;
};

export const apply = async (ctx, config) => {
  const natives = new Map([['opencode', opencodeProvider()], ['opencode-go', opencodeGoProvider()]]);
  const lifetime = new AbortController();
  let active = true;
  let revision = 0;
  let memo;
  let memoKey;
  let registration;
  const catalogs = new Map([...natives].map(([provider, native]) => [provider, new LiveCatalog({
    provider, builtin: new Map(native.getModels().filter((model) => model.type === 'chat' || !model.type).map((model) => [model.id, model])),
    cachePath: join(homedir(), '.dsh', 'cache', 'opencode-live', `${provider}.json`), logger: ctx.logger,
    onRefresh: () => { if (active) { revision++; registration?.replace([...profiles().keys()]); } }
  })]));
  await Promise.all([...catalogs.values()].map((catalog) => catalog.initialize()));
  const profiles = () => {
    const raw = config.providers.get();
    const key = JSON.stringify([revision, raw]);
    if (key !== memoKey) { memo = createProfiles(raw, new Map([...catalogs].map(([id, catalog]) => [id, catalog.value])), natives, false); memoKey = key; }
    return memo;
  };
  profiles();
  const resolveApiKey = async (_provider, profile) => {
    const store = ctx.get('credentials');
    const key = store ? (await store.resolve(profile.apiKeyEnv))?.value : launchEnvironmentOf(ctx).get(profile.apiKeyEnv)?.value;
    if (!key) throw new LlmError('OpenCode Zen credential is not configured', 'MISSING_CREDENTIAL');
    return assertUsableApiKey(key, name, profile.apiKeyEnv);
  };
  const adapter = new PiAiAdapter({
    profiles, resolveApiKey,
    auth: {
      credentials: { read: async () => undefined, list: async () => [], modify: async () => { throw new Error('Use DSH credential settings for OpenCode API keys'); }, delete: async () => { throw new Error('Use DSH credential settings for OpenCode API keys'); } },
      authContext: { env: async (key) => (await ctx.get('credentials')?.resolve(credentialRef(key)))?.value ?? launchEnvironmentOf(ctx).get(key)?.value, fileExists: async () => false }
    },
    resolveAttachments: () => ctx.get('attachments'),
    resolveImageAccess: (attachments, ref) => resolveImageAttachmentAccess(attachments, (path) => ctx.get('fs')?.processPathFromHostPath(path), ref),
    onReplayDegrade: ({ model, reason }) => ctx.logger.warn(`OpenCode ${model}: replay state degraded (${reason})`)
  });
  registration = createDynamicRegistration((providers) => ctx.llm.registerAdapter(providers, adapter));
  registration.replace([...profiles().keys()]);
  const settingsNs = ctx.fiber.entry?.options.id ?? name;
  ctx.llm.registerConfigurableProviders([...natives.keys()].map((provider) => ({ provider, displayName: provider === 'opencode' ? 'OpenCode Zen' : 'OpenCode Go', settingsNs, settingsPath: ['providers', provider], declared: false })));
  ctx.llm.registerModelDiscovery(settingsNs, async (request, signal) => {
    const catalog = catalogs.get(request.provider);
    if (!catalog) throw new LlmError('This discovery supports only OpenCode Zen and Go', 'DISCOVERY_UNSUPPORTED');
    if (request.baseURL && !/^https:\/\/opencode\.ai\/(?:zen|inference)\/(?:go\/)?v1\/?$/.test(request.baseURL)) throw new LlmError('OpenCode live discovery requires its official endpoint', 'DISCOVERY_UNSUPPORTED');
    try {
      const pending = catalog.refresh(lifetime.signal);
      // Caller cancellation stops its wait without cancelling another caller's shared refresh.
      if (signal) await new Promise((resolve, reject) => {
        const abort = () => reject(signal.reason ?? new Error('Discovery cancelled'));
        if (signal.aborted) return abort();
        signal.addEventListener('abort', abort, { once: true });
        pending.then(resolve, reject).finally(() => signal.removeEventListener('abort', abort));
      });
      else await pending;
      return [...catalog.value.models.values()].map((model) => ({ id: model.id, name: model.name, contextWindow: model.contextWindow, maxTokens: model.maxTokens, inputModalities: model.input }));
    } catch (error) {
      ctx.logger.warn(`OpenCode live discovery failed: ${error.message}`);
      throw new LlmError(`OpenCode live discovery failed: ${error.message}`, 'DISCOVERY_FAILED', { cause: error });
    }
  });
  ctx.on('internal/config', function (_raw, next) {
    const raw = next();
    if (this === ctx.fiber) createProfiles(Config(raw).providers.get(), new Map([...catalogs].map(([id, catalog]) => [id, catalog.value])), natives);
    return raw;
  });
  ctx.on('loader/volatile-update', () => { if (active) { profiles(); registration.replace([...profiles().keys()]); } });
  const refresh = () => Promise.all([...catalogs].map(([provider, catalog]) => catalog.refresh(lifetime.signal).catch((error) => {
    if (active) ctx.logger.warn(`${provider} background catalog refresh failed; retaining last valid catalog: ${error.message}`);
  })));
  let nextRefresh = Date.now();
  const timer = setInterval(() => {
    if (Date.now() < nextRefresh) return;
    nextRefresh = Date.now() + config.refreshMinutes.get() * 60000;
    void refresh();
  }, 60000);
  timer.unref();
  ctx.effect(() => () => { active = false; clearInterval(timer); lifetime.abort(); registration.dispose(); });
  void refresh();
};
