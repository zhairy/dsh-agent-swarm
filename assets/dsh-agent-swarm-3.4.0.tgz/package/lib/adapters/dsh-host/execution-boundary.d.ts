import { AsyncLocalStorage } from 'node:async_hooks';
import type { AgentLike, PluginContextLike } from '../../host-contract.js';
export declare const EXECUTION_BOUNDARY_KEY: unique symbol;
export declare const EXECUTION_BOUNDARY_CAPS: unique symbol;
export declare const WRITER_EPOCH: (agentId: string, attemptId: string) => string;
export interface ExecutionBoundaryPolicy {
    agentId: string;
    attemptId: string;
    mode: 'write' | 'read-only' | 'host-worktree';
    operation: 'shell' | 'file' | 'host';
    cwd: string;
    repositoryRoot: string;
    writeScopes: readonly string[];
    expectedDirectoryIdentity?: string;
    assertCurrent: () => void;
}
interface Identity {
    path: string;
    identity: string;
}
interface Epoch {
    active: number;
    unknown: boolean;
    sealed: boolean;
}
interface SpawnSpec {
    argv: readonly string[];
    cwd?: string;
    env?: Record<string, string | undefined>;
    signal?: AbortSignal;
    [key: string]: unknown;
}
interface ProcessHandle {
    done: Promise<unknown>;
    waitForExit: () => Promise<boolean>;
}
interface Scope extends ExecutionBoundaryPolicy {
    epoch: Epoch;
    roots: readonly Identity[];
    anchor: Identity;
    bwrap?: string;
    launcher: string;
    onSettled: (agentId: string) => void;
}
interface Carrier {
    version: 1;
    storage: AsyncLocalStorage<Scope>;
    epochs: Map<string, Epoch>;
    prepareSpawn: (spec: SpawnSpec) => {
        spec: SpawnSpec;
        assertContainment: (mode: string) => void;
        started: (handle: ProcessHandle) => void;
    } | undefined;
    assertFilePath: (path: string) => void;
    assertWorkingDirectory: (agent: AgentLike, current: string, exists?: boolean) => void;
    assertTerminal: () => void;
}
/** Process-persistent carrier: old async callbacks remain fenced across plugin reload. */
export declare const getExecutionBoundaryCarrier: () => Carrier;
export declare const createExecutionBoundary: (ctx: PluginContextLike, onSettled: (agentId: string) => void) => {
    available: () => boolean;
    begin: (agentId: string, attemptId: string) => void;
    seal: (agentId: string, attemptId: string) => boolean;
    quiescent: (agentId: string, attemptId: string) => boolean;
    run: <T>(policy: ExecutionBoundaryPolicy | undefined, next: () => Promise<T>) => Promise<T>;
};
export {};
