import type { AgentLike, PluginContextLike } from '../../host-contract.js';
import type { CreatedWorktreeInfo, WorktreeObservation } from '../../worktree-binding.js';
export interface WorktreeHostPort {
    cwd: (agent: AgentLike) => string;
    setCwd: (agent: AgentLike, path: string, signal: AbortSignal) => Promise<string>;
    inspect: (agent: AgentLike, record: CreatedWorktreeInfo, signal: AbortSignal) => Promise<WorktreeObservation>;
}
/** No direct process/file access: all inspection is confined by the calling Host policy. */
export declare const createHostWorktreePort: (ctx: PluginContextLike) => WorktreeHostPort;
