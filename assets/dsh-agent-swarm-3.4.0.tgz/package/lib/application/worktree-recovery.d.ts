import type { AgentLike } from '../host-contract.js';
import type { SwarmEventJournal } from '../event-journal.js';
import { type WorktreeBindingInfo, type WorktreeOwner, type WorktreeRegistry } from '../worktree-binding.js';
import type { WorktreeHostPort } from '../adapters/dsh-host/worktree.js';
import type { WorkspaceLease, WorkspaceLeaseManager } from '../util/workspace-lease.js';
export interface RestoreWorktreeInput {
    id: string;
    agent: AgentLike;
    owner: WorktreeOwner;
    signal: AbortSignal;
    registry: WorktreeRegistry;
    journal: SwarmEventJournal;
    host: WorktreeHostPort;
    leases: WorkspaceLeaseManager;
    lock: {
        run: <T>(operation: () => Promise<T>) => Promise<T>;
    };
    assertCurrent: () => void;
    confirmStopped: (previous: WorktreeBindingInfo) => Promise<void>;
    assertStopped: (previous: WorktreeBindingInfo) => void;
    getLease: (record: WorktreeBindingInfo) => WorkspaceLease | undefined;
    retainLease: (lease: WorkspaceLease, record: WorktreeBindingInfo) => void;
    warn: (message: string) => void;
}
/** The only ownership publication path; durable commit and activation are separate boundaries. */
export declare const restoreRetainedWorktree: (input: RestoreWorktreeInput) => Promise<WorktreeBindingInfo>;
